//    PA_control.c helper functions to communicate to Arduino, which communicates with PA
//    written by Danny Holstein

#ifdef WIN
 #include <windows.h>
 #define EXPORT __stdcall __declspec(dllexport)
 #include <winuser.h>
 #define WIN_CALL __stdcall
 typedef long ulong;
#else
 #define EXPORT
 #define _GNU_SOURCE
 #define WIN_CALL
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <stdbool.h>

#define HANDLEERROR() {printf("%s:%d\tLast error = %d\n", __FUNCTION__, __LINE__, GetLastError()); CloseHandle(hComm); return 0;}
#define MAX_BUF_LEN 100
#define MAX_DATA_SETS 51
#define SRC_ADDR 0x1
#define DEST_ADDR 0xFE
#define CHECK_COMM(HCOMM) HCOMM != 0

#ifndef DLL
	#define DEBUG
#endif


char debug[MAX_BUF_LEN];

#if 1	// PA-specific function definitions
char WIN_CALL PA_Cmd(HANDLE hComm, char cmd, unsigned int state);
char WIN_CALL PA_GetCmd(HANDLE hComm, char cmd, char* buffer, char* buflen);
char WIN_CALL PA_KeepAlive(HANDLE hComm, char cmd, bool state, int TIMO);
char WIN_CALL PA_KeepAliveQuery(HANDLE hComm, char* buffer, char length, int TIMO);
char WIN_CALL PA_Sweep(HANDLE hComm, char cmd, char* buffer, int* buflen, int NumSweeps);

void BuildBuffer(char dest, char src, char cmd, char* buffer, bool ON_State);
HANDLE WIN_CALL OpenPA(char* SerialPort, char* Config, int TIMO);
#define ClosePA(hComm) CloseHandle(hComm)
char Query(char* SerialPort, char* Config, char* cmd, char* buffer, int length, int TIMO);
char WIN_CALL QueryH(HANDLE hComm, char* cmd, char* buffer, int length);
int QueryBinH(HANDLE hComm, char* cmd, int CmdLen, char* buffer, int RespLen, int delay, int TIMO);
char* GetInstrID(char* SerialPort, char* Config, char* buffer, int length);
char SetTimeout(HANDLE hComm, int TIMO);
char WIN_CALL StrGetCommPorts(char* buffer, int length);
#endif
unsigned int CalculateCRC16(unsigned char *buffer, unsigned char length);

#if 0	//	ALLDATA definition
typedef struct {	//	A/D converters are 12 bits. This is intended for VBA calls, which doesn't support unsigned.
    unsigned char dest;			//   Destination (same as source from cmd packet)
    unsigned char src;			//   Source (as determined by PA dipsw)
    unsigned char len;			//   Length
    unsigned char cmd;			//   Command (GET_ALL_DATA)
    unsigned char pa_status;	//   PA Status (0=OFF, 1=ON)
    unsigned char COMPAT;		//   Software compatibility number (currently 0x80)
    unsigned int fwd_pwr;		//   Forward Power (100mW steps (e.g. 328 = 32.8W))
    unsigned int rev_pwr;		//   Reverse Power (100mW steps)
    unsigned short pa_volts;	//   PA voltage (10mV steps)
    unsigned short pa_temp;		//   PA temperature (highest reading) (0.1degC steps)
    unsigned short sw_ver;		//   Software Version
    unsigned short ambient;		//   Ambient temperature (0.1degC steps)
    unsigned short drv_pwr;		//   not used
    unsigned short pa1_curr;	//   PA 1 current (1mA steps)
    unsigned short pa2_curr;	//   PA 2 current (1mA steps)
    unsigned short pa3_curr;	//   PA 3 current (1mA steps)
    unsigned short pa4_curr;	//   not used
    unsigned short pa5_curr;	//   not used
    unsigned short pa6_curr;	//   not used
    unsigned short pa7_curr;	//   not used
    unsigned short pa8_curr;	//   not used
    unsigned char pa_faults;	//   PA Faults (see below)
    unsigned short crc;     	//   CRC16
} ALLDATA;
#endif

#if 1	// PA-specific structures
typedef struct {
    unsigned char dest;			//   Destination (same as source from cmd packet)
    unsigned char src;			//   Source (as determined by PA dipsw)	
    unsigned char len;			//   Length
    unsigned char cmd;			//   Command
    unsigned int data;			//   data
    unsigned short crc;			//   CRC16
} PA_CMD_DATA;
typedef struct {
    unsigned char dest;			//   Destination (same as source from cmd packet)
    unsigned char src;			//   Source (as determined by PA dipsw)	
    unsigned char len;			//   Length
    unsigned char cmd;			//   Command
    unsigned short crc;			//   CRC16
} PA_CMD_NODATA;
union COMMAND {
   PA_CMD_DATA Data;
   PA_CMD_NODATA NoData;
   unsigned char Buffer[9];
};
//---commands
#define Set_PA_Status 0x1
#define Clear_PA_faults 0x2
#define Set_test_mode 0x3	//	not currently a thing. PA uses averaging over 1 second before sending data, I'd like to turn off averaging.
#define Get_PA_status 0x81
#define Get_all_data 0x82
#define Get_faults 0x83

#define PA_ON 0x48444D42
#define PA_OFF 0x00000000
#endif

char InstrID[MAX_BUF_LEN];
HANDLE hComm;

#ifndef DLL
int main()
{
	char res[MAX_BUF_LEN], swp_res[MAX_DATA_SETS*MAX_BUF_LEN], *CommStr = "COM9",  *CommCFG = "baud=115200 parity=N data=8 stop=1";
	int i, k, NumSweeps=11; char n=0;
	// ALLDATA AllData;
	union COMMAND Command;
	
#ifdef TEST_PORT_DETECTION 
	if ((n = StrGetCommPorts(res, MAX_BUF_LEN))>0) {
		printf("%s", res);
	}
#endif

#if 0 
	#if 0 
		if (GetInstrID(CommStr, CommCFG, InstrID, MAX_BUF_LEN)) printf("%s:%d\tIDENT: %s\n", __FUNCTION__, __LINE__, InstrID);
		else {printf("%s:%d\tLast error = %d\n", __FUNCTION__, __LINE__, GetLastError());}
		
		if (Query(CommStr, CommCFG, "rfmute 1", res, MAX_BUF_LEN, 2000, true)) printf("%s:%d\tReponse: %s\n", __FUNCTION__, __LINE__, res);
	#else
		if ((hComm = OpenPA(CommStr, CommCFG, 2000)) == 0) HANDLEERROR();
		if (QueryH(hComm, "*idn?\n", res, MAX_BUF_LEN, true)) printf("%s:%d\tReponse: %s\n", __FUNCTION__, __LINE__, res);
		if (QueryH(hComm, "rfmute 1", res, MAX_BUF_LEN, true)) printf("%s:%d\tReponse: %s\n", __FUNCTION__, __LINE__, res);
		ClosePA(hComm);
	#endif
#endif

	if ((hComm = OpenPA(CommStr, CommCFG, 2000)) == 0) HANDLEERROR();
	if (QueryH(hComm, "*idn?\n", res, MAX_BUF_LEN)) printf("%s:%d\tReponse: %s\n", __FUNCTION__, __LINE__, res);
#if 0 
	
	if (QueryH(hComm, "intlk 0\n", res, MAX_BUF_LEN)) printf("%s:%d\tReponse: %s\n", __FUNCTION__, __LINE__, res);
	BuildBuffer(SRC_ADDR, DEST_ADDR, Get_all_data, Command.Buffer, true);
	
	n = QueryBinH(hComm, "query\n", strlen("query\n"), res, 1, 0, 2000);	//	start binary query
	if (n==1 && res[0]==':') {	//	wait for ':'
		printf("%s:%d\tQuery sent\n", __FUNCTION__, __LINE__);
		res[0]=Command.Data.len+5; n = QueryBinH(hComm, res, 1, res, 0, 0, 1000);	//	send one byte length, no expected response
		n = QueryBinH(hComm, Command.Buffer, Command.Data.len+5, res, 1, 0, 2000);	//	send complete command, wait for Arduino to send one byte response length
		k = res[0]; n = QueryBinH(hComm, Command.Buffer, 0, res, k, 0, 2000);		//	get response
#ifdef DEBUG		
		for (i=0; i<k; i++) {printf("res[%d] = 0x%02x\n", i, (unsigned char) res[i]);}
#endif
	}
#endif
	
	k = 0;
	unsigned short crc, rec_crc;
	
	do {
		n = MAX_BUF_LEN;
		(void) PA_GetCmd(hComm, Get_all_data, res, &n);
		crc = CalculateCRC16(res, *(res+2)+3); memmove(&rec_crc, res+n-2, 2); rec_crc = htons(rec_crc);
		if (++k > 4) break;
	}
	while (crc != rec_crc);
	if (n) {for (i=0; i<n; i++) {printf("res[%02d] = 0x%02x\n", i, (unsigned char) res[i]);}; printf("crc=0x%04x\n\n", crc);}
	
	k = MAX_DATA_SETS*MAX_BUF_LEN;
	char *swp_pos;
	swp_pos = swp_res;
	if (PA_Sweep(hComm, Get_all_data, swp_res, &k, NumSweeps)) {
		for (i=0; i<NumSweeps; i++) {
			k = *(swp_pos + 2)+3;
			for (int j=0; j<k; j++) {printf("res[%02d] = 0x%02x\n", j, (unsigned char) swp_pos[j]);}
			printf("crc=0x%02x%02x\n\n", (unsigned char) swp_pos[k], (unsigned char) res[k+1]);
			swp_pos += n;
		}
	}
	
#ifdef KEEP_ALIVE_FUNCT
	printf("Set_PA_Status %s\n", (PA_Cmd(hComm, Set_PA_Status, PA_ON)? "SUCCESS": "FAILURE")); printf("%s:%d\tDebug\n\n", __FUNCTION__, __LINE__);
	printf("Keep Alive: cmd=0x%02x, state=%s, TIMO=%d ms %s\n", Get_all_data, "PA_ON", 250, (PA_KeepAlive(hComm, Get_all_data, false, 250)? "SUCCESS": "FAILURE")); printf("%s:%d\tDebug\n\n", __FUNCTION__, __LINE__);
	Sleep(1000);
	printf("\nKeep Alive Response: Length=%d\n", PA_KeepAliveQuery(hComm, res, MAX_BUF_LEN, 200)); printf("%s:%d\tDebug\n\n", __FUNCTION__, __LINE__);
	printf("Keep Alive: cmd=0x%02x, state=%s, TIMO=%d ms %s\n", Set_PA_Status, "PA_OFF", 250, (PA_KeepAlive(hComm, Get_all_data, false, 250)? "SUCCESS": "FAILURE")); printf("%s:%d\tDebug\n\n", __FUNCTION__, __LINE__);
#endif
	
	ClosePA(hComm);
    return 0;
}
#endif

#ifdef DEBUG
	#define NOT_SUCCESSFUL() {printf("%s:%d\tFailure\n", __FUNCTION__, __LINE__);for (i=0; i<*buflen; i++) {*(buffer+i) = 0;} *buflen = 0; return 0;}
	#define FAIL_RTN() {printf("%s:%d\tFailure\n", __FUNCTION__, __LINE__); return 0;}
#else
	#define NOT_SUCCESSFUL() {for (i=0; i<*buflen; i++) {*(buffer+i) = 0;} *buflen = 0; return 0;}
	#define FAIL_RTN() {return 0;}
#endif

char WIN_CALL PA_Sweep(HANDLE hComm, char cmd, char* buffer, int* buflen, int NumSweeps){
	int n=0, i, j, k;
	char PA_Cmd[15], lil_buf[15];
	union COMMAND Command;
	
	if (!CHECK_COMM(hComm)) NOT_SUCCESSFUL();
	switch((unsigned char) cmd) {
		case Get_all_data:
			break;
		default :
			NOT_SUCCESSFUL()	//	not a "sweep" command
	}
	
	BuildBuffer(SRC_ADDR, DEST_ADDR, cmd, Command.Buffer, true);
	sprintf(PA_Cmd, "sweep %d\n", NumSweeps);
	n = QueryBinH(hComm, PA_Cmd, strlen(PA_Cmd), buffer, 1, 0, 2000);	//	start binary query
	if (n==1 && buffer[0]==':') {												//	wait for ':'
		buffer[0]=Command.Data.len+5; n = QueryBinH(hComm, buffer, 1, buffer, 0, 0, 1000);	//	send one byte length, no expected response
		n = QueryBinH(hComm, Command.Buffer, Command.Data.len+5, buffer, 2, 0, NumSweeps*3000);		//	send complete command, wait for Arduino to send two byte response, ':' and length
		if (n==2 && buffer[0]==':') {k = buffer[1];}
		else NOT_SUCCESSFUL();
		
		for (i=0, j=0; i<NumSweeps; i++, j += n) {
			n = QueryBinH(hComm, 0, 0, lil_buf, 1, 0, 2000);			//	get length
			if (n == 0) NOT_SUCCESSFUL()
			n = QueryBinH(hComm, 0, 0, buffer+j, lil_buf[0], 0, 2000);			//	get response
			if (n == 0) NOT_SUCCESSFUL()
			else *buflen = j + n;
		}
	}
	else NOT_SUCCESSFUL();
	
	return 1;	//	success
}
	
char WIN_CALL PA_Cmd(HANDLE hComm, char cmd, unsigned int status){
	int n=0, i, k;
	union COMMAND Command;
	char buffer[1];
	
	if (!CHECK_COMM(hComm)) FAIL_RTN();
	switch((unsigned char) cmd) {
		case Set_PA_Status:
		case Clear_PA_faults:
			break;
		default :
			FAIL_RTN();	//	not a command
	}
	
	BuildBuffer(SRC_ADDR, DEST_ADDR, cmd, Command.Buffer, status);
	n = QueryBinH(hComm, "cmd\n", strlen("cmd\n"), buffer, 1, 0, 2000);	//	start binary query
	if (n==1 && buffer[0]==':') {												//	wait for ':'
		// printf("%s:%d\tQuery sent\n", __FUNCTION__, __LINE__);
		buffer[0]=Command.Data.len+5; n = QueryBinH(hComm, buffer, 1, buffer, 0, 0, 1000);	//	send one byte length, no expected response
		n = QueryBinH(hComm, Command.Buffer, Command.Data.len+5, buffer, 0, 0, 2000);		//	send complete command, wait for Arduino to send one byte response length
	}
	else FAIL_RTN();
	
	return 1;
}

char WIN_CALL PA_GetCmd(HANDLE hComm, char cmd, char* buffer, char* buflen){
	int n=0, i, k;
	union COMMAND Command;
	
	if (!CHECK_COMM(hComm)) NOT_SUCCESSFUL();
	switch((unsigned char) cmd) {
		case Get_PA_status:
		case Get_all_data:
		case Get_faults:
			break;
		default :
			NOT_SUCCESSFUL()	//	not a "get" command
	}
	
	BuildBuffer(SRC_ADDR, DEST_ADDR, cmd, Command.Buffer, true);
	n = QueryBinH(hComm, "query\n", strlen("query\n"), buffer, 1, 0, 2000);	//	start binary query
	if (n==1 && buffer[0]==':') {												//	wait for ':'
		// printf("%s:%d\tQuery sent\n", __FUNCTION__, __LINE__);
		buffer[0]=Command.Data.len+5; n = QueryBinH(hComm, buffer, 1, buffer, 0, 0, 1000);	//	send one byte length, no expected response
		n = QueryBinH(hComm, Command.Buffer, Command.Data.len+5, buffer, 1, 0, 2000);		//	send complete command, wait for Arduino to send one byte response length
		k = buffer[0]; n = QueryBinH(hComm, Command.Buffer, 0, buffer, k, 0, 2000);			//	get response
		if (n == 0) NOT_SUCCESSFUL()
		else *buflen = n;
	}
	else NOT_SUCCESSFUL();
	
	return 1;	//	success
}

#ifdef KEEP_ALIVE_FUNCT
char WIN_CALL PA_KeepAlive(HANDLE hComm, char cmd, bool state, int TIMO){
	int n=0, i, k;
	union COMMAND Command;
	char cmd_buf[50], buf[1];
	
	switch((unsigned char) cmd) {
		case Set_PA_Status:
		case Clear_PA_faults:
		case Get_PA_status:
		case Get_all_data:
		case Get_faults:
			break;
		default :
			FAIL_RTN();	//	not a command
	}
	
	BuildBuffer(SRC_ADDR, DEST_ADDR, cmd, Command.Buffer, state);
	sprintf(cmd_buf, "keep-alive %d\n", TIMO);
	n = QueryBinH(hComm, cmd_buf, strlen(cmd_buf), buf, 1, 20, 2000);	//	start binary query
	if (n==1 && buf[0]==':') {												//	wait for ':'
		printf("%s:%d\tKeep Alive sent\n", __FUNCTION__, __LINE__);
		buf[0]=Command.Data.len+5; n = QueryBinH(hComm, buf, 1, buf, 0, 0, 1000);	//	send one byte length, no expected response
		n = QueryBinH(hComm, Command.Buffer, Command.Data.len+5, buf, 0, 0, 2000);		//	send complete command, wait for Arduino to send one byte response length
	}
	else FAIL_RTN();
	
	return 1;	//	success
}

char WIN_CALL PA_KeepAliveQuery(HANDLE hComm, char* buffer, char length, int TIMO){
	char rtnval;
	rtnval = QueryBinH(hComm, "KAQuery\n", strlen("KA_Query\n"), buffer, 0, 0, TIMO); printf("\n%s:%d\tbytes read %d\n", __FUNCTION__, __LINE__, rtnval);
	rtnval = QueryBinH(hComm, "", 0, buffer, 2, 20, TIMO); printf("\n%s:%d\tbytes read %d\n", __FUNCTION__, __LINE__, rtnval);
	return rtnval;
}
#endif

void BuildBuffer(char dest, char src, char cmd, char* buffer, bool ON_State){
	union COMMAND *Buf;
	Buf = (union COMMAND *) buffer;
	
	Buf->Data.dest = dest; Buf->Data.src = src;
	Buf->Data.cmd = cmd; Buf->Data.len = 1;
	if (cmd == Set_PA_Status) {
		Buf->Data.len += 4;
		Buf->Data.data = (ON_State? htonl(PA_ON) : PA_OFF);
		Buf->Data.crc = htons((unsigned short) CalculateCRC16(buffer, Buf->Data.len+3));
	}
	else {
		Buf->NoData.crc = htons((unsigned short) CalculateCRC16(buffer, Buf->Data.len+3));
	}
}

char* GetInstrID(char* SerialPort, char* Config, char* buffer, int length)
{
	if (!Query(SerialPort, Config, "*idn?\n", buffer, length, 1000)) return 0;
	return buffer;
}

HANDLE WIN_CALL OpenPA(char* SerialPort, char* Config, int TIMO)
{
	HANDLE hComm; DCB dcb; COMMTIMEOUTS CommTimeouts;	//	comm structures
	// MessageBox(0, Config, "Danny Rules!", 0); return 0;
	hComm = CreateFile(SerialPort, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	if (hComm == INVALID_HANDLE_VALUE) HANDLEERROR()	//	check open
	if (!BuildCommDCBA(Config, &dcb)) return 0;			//	set configuration
	if (!SetCommState(hComm, &dcb)) HANDLEERROR()		//	configure
	if (!PurgeComm(hComm, 0XF)) HANDLEERROR()			//	clear operations and buffer
	
	CommTimeouts.ReadIntervalTimeout = 10; CommTimeouts.ReadTotalTimeoutMultiplier = 10; CommTimeouts.ReadTotalTimeoutConstant = TIMO;
	CommTimeouts.WriteTotalTimeoutMultiplier = 10; CommTimeouts.WriteTotalTimeoutConstant = 100;
	if (!SetCommTimeouts(hComm, &CommTimeouts)) HANDLEERROR()		//	set timeout
	return hComm;
}

char WIN_CALL QueryH(HANDLE hComm, char* cmd, char* buffer, int buflen)
{	//	send newline terminated command to PA Controller, get newline terminated string back
	int dwWritten, dwRead=0, i = 0;
	buffer[0] = 0;
	
	if (!WriteFile(hComm, cmd, strlen(cmd), &dwWritten, NULL)) HANDLEERROR();	//	write command
#ifdef DEBUG
	printf("%s:%d\tcmd=%s\twrote %d bytes\n", __FUNCTION__, __LINE__, cmd, dwWritten);
#endif

	while (buffer[(i ? i-1 : 0)] != 10) {
		if (!ReadFile(hComm, buffer+i, 1, &dwRead, 0)) HANDLEERROR()
		if (!(dwRead || i)) {if (!WriteFile(hComm, cmd, strlen(cmd), &dwWritten, NULL)) HANDLEERROR();}	//	TIMO: resend command
		i += dwRead; // printf("%s:%d\t\tread %d bytes, char=%d, '%c'\n", __FUNCTION__, __LINE__, i, buffer[(i ? i-1 : 0)], buffer[(i ? i-1 : 0)]);
		if (i>buflen) break;
	}
	buffer[i] = 0;
	 
	return 1;
}

int QueryBinH(HANDLE hComm, char* cmd, int CmdLen, char* buffer, int RespLen, int delay, int TIMO)
{	//	send CmdLen length command to PA Controller, get RespLen length response back, return actual bytes read
	int dwWritten, dwRead=0, i;
	
	if (!CHECK_COMM(hComm)) HANDLEERROR();
	if (CmdLen) {
		if (!WriteFile(hComm, cmd, CmdLen, &dwWritten, NULL)) HANDLEERROR();	//	write command 
#ifdef DEBUG
			printf("%s:%d\twrote %d bytes\ndata sent: ", __FUNCTION__, __LINE__, dwWritten); for (i=0; i<CmdLen; i++) {
				int dum = (cmd[i]>31 && cmd[i]<127 ? sprintf(debug, "/'%c' ", cmd[i]): sprintf(debug, " "));
				printf(" %d:0x%02x%s", i, (unsigned char) cmd[i], debug);
			};
			printf("\n");
#endif
		if (delay) Sleep(delay);
	}
	
	if (TIMO) SetTimeout(hComm, TIMO); 
	i=0;
	while (i<RespLen) {
		if (!ReadFile(hComm, buffer+i, 1, &dwRead, 0)) HANDLEERROR()
		i += dwRead;
		if (!dwRead) {
			printf("%s:%d\t\tread %d bytes, TIMEOUT", __FUNCTION__, __LINE__, i);
			break;
		}
	}
	
	return i;
}

char Query(char* SerialPort, char* Config, char* cmd, char* buffer, int buflen, int TIMO)
{	//	send newline terminated command to PA Controller, get newline terminated string back
	int dwWritten, dwRead=0, i = 0;
	HANDLE hComm; DCB dcb; 	//	comm structures
	
	hComm = CreateFile(SerialPort, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	if (hComm == INVALID_HANDLE_VALUE) HANDLEERROR()	//	check open
	if (!BuildCommDCBA(Config, &dcb)) return 0;			//	set configuration
	if (!SetCommState(hComm, &dcb)) HANDLEERROR()		//	configure
	if (!PurgeComm(hComm, 0XF)) HANDLEERROR()			//	clear operations and buffer
	buffer[0] = 0;
	
	if (!SetTimeout(hComm, TIMO)) HANDLEERROR();
	if (!WriteFile(hComm, cmd, strlen(cmd), &dwWritten, NULL)) HANDLEERROR();	//	write command
	printf("%s:%d\tcmd=%s\twrote %d bytes\n", __FUNCTION__, __LINE__, cmd, dwWritten);

	while (buffer[(i ? i-1 : 0)] != 10) {
		if (!ReadFile(hComm, buffer+i, 1, &dwRead, 0)) HANDLEERROR()
		if (!(dwRead || i)) {if (!WriteFile(hComm, cmd, strlen(cmd), &dwWritten, NULL)) HANDLEERROR();}	//	TIMO: resend command
		i += dwRead; // printf("%s:%d\t\tread %d bytes, char=%d, '%c'\n", __FUNCTION__, __LINE__, i, buffer[(i ? i-1 : 0)], buffer[(i ? i-1 : 0)]);
		if (i>buflen) break;
	}
	buffer[i] = 0;
	 
	CloseHandle(hComm);
	return 1;
}

char SetTimeout(HANDLE hComm, int TIMO)
{
	COMMTIMEOUTS CommTimeouts;
	CommTimeouts.ReadIntervalTimeout = TIMO; CommTimeouts.ReadTotalTimeoutMultiplier = 10; CommTimeouts.ReadTotalTimeoutConstant = TIMO;
	CommTimeouts.WriteTotalTimeoutMultiplier = 10; CommTimeouts.WriteTotalTimeoutConstant = 100;
	if (!SetCommTimeouts(hComm, &CommTimeouts)) HANDLEERROR()		//	set timeout
	return 1;
}

char WIN_CALL StrGetCommPorts(char* buffer, int length)
{   /*  return list of COMM ports  */
#define MAX_PORTS 25
	int n=0, i;
	ULONG  uPortNumbersCount=0, puPortNumbersFound;
	ULONG lpPortNumbers[MAX_PORTS];
	buffer[0] = 0;
	GetCommPorts(lpPortNumbers,  MAX_PORTS, &puPortNumbersFound);

	for (i=0; i<puPortNumbersFound; i++) {
		n = length - strlen(buffer);
		if (snprintf(buffer + strlen(buffer), n, "COM%u\n", lpPortNumbers[i]) > n) return -1;
		}
	return puPortNumbersFound;
}

//---------------------------------------------------------------------------
const unsigned short CRC16_CCITT_TAB[256] = {
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
    0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
    0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
    0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
    0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
    0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
    0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
    0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
    0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
    0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
    0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
    0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
    0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
    0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
    0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
    0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
    0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
    0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
    0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
    0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
    0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
    0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
    0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};


//---------------------------------------------------------------------------
// Function: ProcessPacket
// Description: Calculate CCITT CRC16 for selected frame.
//---------------------------------------------------------------------------
unsigned int CalculateCRC16(unsigned char *buffer, unsigned char length)
{
    unsigned int crc;
    
    crc = 0xFFFF;

    do {
        crc=(unsigned int)((crc<<8)^CRC16_CCITT_TAB[((unsigned char)(crc>>8))^*buffer]);
        buffer++;
        length--;
    }
    while (length);
    crc ^= 0xFFFF;

    return crc;
}
